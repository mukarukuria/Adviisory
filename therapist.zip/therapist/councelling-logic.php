<?php
require '../includes/config.php';

echo $_SESSION['patient-id'];


	
											
										

																
										
											
										

										
		
?>